package com.zedr_apps.networkstatedemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.anshulthakur.networkstatechecker.InternetStateChecker;
import com.anshulthakur.networkstatedemo.R;

public class MainActivity extends AppCompatActivity {

    InternetStateChecker checker;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        checker = new InternetStateChecker.Builder(this).build();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        checker.stop();
    }
}
