package com.zedr_apps.networkstatechecker;

public interface ConnectivityReceiverListener {
    void onNetworkConnectionChanged(boolean isConnected);
}
